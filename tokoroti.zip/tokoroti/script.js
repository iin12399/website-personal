document.addEventListener('DOMContentLoaded', () => {
    const orderForm = document.getElementById('order-form');
    const quantityClassicBread = document.getElementById('quantity-classic-bread');
    const quantityBoluCake = document.getElementById('quantity-bolu-cake');
    const quantitySurabi = document.getElementById('quantity-surabi');
    const quantityKueGoreng = document.getElementById('quantity-kue-goreng');
    const quantityKueBalok = document.getElementById('quantity-kue-balok');
    const quantityKueApe = document.getElementById('quantity-kue-ape'); 
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            document.getElementById('contact-notification').style.display = 'block';
            setTimeout(() => {
                document.getElementById('contact-notification').style.display = 'none';
            }, 3000);
            contactForm.reset();
        });
    }

    if (orderForm) {
        orderForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const classicBreadPrice = 10000;
            const boluCakePrice = 5000;
            const surabiPrice = 7000;
            const kueGorengPrice = 3000;
            const kueBalokPrice = 12000;
            const kueApePrice = 5000;

            const quantityClassic = parseInt(quantityClassicBread.value, 10) || 0;
            const quantityBolu = parseInt(quantityBoluCake.value, 10) || 0;
            const quantitySurabiValue = parseInt(quantitySurabi.value, 10) || 0;
            const quantityKueGorengValue = parseInt(quantityKueGoreng.value, 10) || 0;
            const quantityKueBalokValue = parseInt(quantityKueBalok.value, 10) || 0;
            const quantityKueApeValue = parseInt(quantityKueApe.value, 10) || 0;
            const address = orderForm.address.value;

            const totalClassic = classicBreadPrice * quantityClassic;
            const totalBolu = boluCakePrice * quantityBolu;
            const totalSurabi = surabiPrice * quantitySurabiValue;
            const totalKueGoreng = kueGorengPrice * quantityKueGorengValue;
            const totalKueBalok = kueBalokPrice * quantityKueBalokValue;
            const totalKueApe = kueApePrice * quantityKueApeValue;

            const totalPrice = totalClassic+totalBolu+totalSurabi+totalKueGoreng+totalKueBalok+totalKueApe;

            const invoiceDetails = `
                <p>Classic Bread: ${quantityClassic} x 10,000 IDR = ${totalClassic.toLocaleString()} IDR</p>
                <p>Bolu Cake: ${quantityBolu} x 5,000 IDR = ${totalBolu.toLocaleString()} IDR</p>
                <p>Surabi: ${quantitySurabiValue} x 7,000 IDR = ${totalSurabi.toLocaleString()} IDR</p>
                <p>Kue Goreng: ${quantityKueGorengValue} x 3,000 IDR = ${totalKueGoreng.toLocaleString()} IDR</p>
                <p>Kue Balok: ${quantityKueBalokValue} x 12,000 IDR = ${totalKueBalok.toLocaleString()} IDR</p>
                <p>Kue Ape: ${quantityKueApeValue} x 5,000 IDR = ${totalKueApe.toLocaleString()} IDR</p>
            `;
            const invoiceTotal = `Total: ${totalPrice.toLocaleString()} IDR`;
            const invoiceAddress = `Delivery Address: ${address}`;

            localStorage.setItem('invoiceDetails', invoiceDetails);
            localStorage.setItem('invoiceTotal', invoiceTotal);
            localStorage.setItem('invoiceAddress', invoiceAddress);

            window.location.href = 'invoice.html';
        });
    }

    const invoiceDetailsElement = document.getElementById('invoice-details');
    const invoiceTotalElement = document.getElementById('invoice-total');
    const invoiceAddressElement = document.getElementById('invoice-address');

    if (invoiceDetailsElement && invoiceTotalElement && invoiceAddressElement) {
        const storedInvoiceDetails = localStorage.getItem('invoiceDetails');
        const storedInvoiceTotal = localStorage.getItem('invoiceTotal');
        const storedInvoiceAddress = localStorage.getItem('invoiceAddress');

        if (storedInvoiceDetails && storedInvoiceTotal && storedInvoiceAddress) {
            invoiceDetailsElement.innerHTML = storedInvoiceDetails;
            invoiceTotalElement.textContent = storedInvoiceTotal;
            invoiceAddressElement.textContent = storedInvoiceAddress;

            // Clear localStorage after displaying the invoice
            localStorage.removeItem('invoiceDetails');
            localStorage.removeItem('invoiceTotal');
            localStorage.removeItem('invoiceAddress');

        }
    }

    // Ensure quantity inputs are within valid range
    document.querySelectorAll('input[type="number"]').forEach(input => {
        input.addEventListener('input', () => {
            let value = parseInt(input.value, 10);
            if (isNaN(value)) {
                input.value = 0;
            } else if (value < 0) {
                input.value = 0;
            } else if (value > 20) {
                input.value = 20;
            }
        });
    });
});
